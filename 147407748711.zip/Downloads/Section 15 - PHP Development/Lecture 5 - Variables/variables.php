<!DOCTYPE html>
<html>

<body>

<?php
$var1 = "Hello world!";
$x = 15;
$y = 20.5;

echo $var1;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
echo "<hr />";

$sport= "Football";
echo "I like $sport!";
echo "<hr />";

$sport= "Football";
echo "I like " . $sport . "!";
echo "<hr />";

$x = 5;
$y = 6;
echo $x + $y;

?>

</body>
</html>